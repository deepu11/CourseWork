Basic documentation location:

http://selenium-python.readthedocs.io/

Chrome drivers here:

https://sites.google.com/a/chromium.org/chromedriver/downloads

Unittest docs here:

https://docs.python.org/3/library/unittest.html


