import unittest

class MyTestCase(unittest.TestCase):
    def test_example(self):
	pass

unittest.main(verbosity=2)


